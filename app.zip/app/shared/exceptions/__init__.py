"""
Custom exceptions package containing application-specific exceptions.
""" 