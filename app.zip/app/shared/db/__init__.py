"""
Database utilities package containing session management and database initialization.
""" 