"""
Dependency injection utilities.
"""

from typing import Any, Generator

from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.shared.core.exceptions import AuthenticationException
from app.shared.core.security.auth_core import decode_token, oauth2_scheme
from app.shared.core.security.roles import Role
from app.shared.db.session import get_db
from sqlalchemy.orm import Session
from fastapi import Depends
from app.shared.models.user import User
from app.shared.db.session import get_db
from fastapi import HTTPException
from typing import Any
from sqlalchemy.orm import Session
from fastapi import Depends
from app.shared.models.user import User
from app.shared.db.session import get_db
from fastapi import HTTPException
from typing import Any


def get_db_session() -> Generator[Session, None, None]:
    """
    Get database session.
    """
    return get_db()

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db_session)
) -> Any:
    """
    Get current user from JWT token.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_token(token)
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except AuthenticationException:
        raise credentials_exception
    
    # Use string reference to avoid circular import
    user = db.query("User").filter_by(id=user_id).first()
    if user is None:
        raise credentials_exception
    return user

async def get_current_active_user(
    current_user: Any = Depends(get_current_user)
) -> Any:
    """
    Get current active user.
    """
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

async def get_current_superuser(
    current_user: Any = Depends(get_current_active_user)
) -> Any:
    """
    Get current superuser.
    """
    if current_user.role != Role.SUPERUSER:
        raise HTTPException(
            status_code=403, detail="The user doesn't have enough privileges"
        )
    return current_user

async def get_current_customer(
    current_user: Any = Depends(get_current_active_user),
    db: Session = Depends(get_db_session)
) -> Any:
    """
    Get current customer.
    """
    customer = db.query("Customer").filter_by(id=current_user.customer_id).first()
    if not customer:
        raise HTTPException(
            status_code=404,
            detail="Customer not found"
        )
    return customer

async def get_current_active_customer(
    current_customer: Any = Depends(get_current_customer)
) -> Any:
    """
    Get current active customer.
    """
    if not current_customer.is_active:
        raise HTTPException(status_code=400, detail="Inactive customer")
    return current_customer

async def get_current_tenant(
    current_customer: Any = Depends(get_current_active_customer)
) -> str:
    """
    Get current tenant identifier.
    """
    return current_customer.customer_id

def get_current_user_dep():
    """
    Get current user dependency.
    """
    return get_current_user

def get_current_active_user_dep():
    """
    Get current active user dependency.
    """
    return get_current_active_user

def get_current_superuser_dep():
    """
    Get current superuser dependency.
    """
    return get_current_superuser

def get_current_customer_dep():
    """
    Get current customer dependency.
    """
    return get_current_customer 