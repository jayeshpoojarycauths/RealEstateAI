"""
Logger configuration.
"""

import logging
import sys
from pathlib import Path
from typing import Optional

from app.shared.core.config import settings
from app.shared.core.logging import logger
from app.shared.core.logging import logger


def setup_logger(
    name: str,
    level: Optional[int] = None,
    log_file: Optional[str] = None
) -> logging.Logger:
    """
    Set up a logger with the given name and level.
    """
    logger = logging.getLogger(name)
    
    if level is None:
        # Use DEBUG level by default, can be overridden by environment variables
        level = logging.DEBUG
    
    logger.setLevel(level)
    
    # Create formatters
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    console_formatter = logging.Formatter(
        '%(levelname)s - %(message)s'
    )
    
    # Create handlers
    handlers = []
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_formatter)
    handlers.append(console_handler)
    
    # File handler
    if log_file:
        # Use LOG_FILE setting if available, otherwise use default path
        log_path = Path(settings.LOG_FILE) if hasattr(settings, 'LOG_FILE') else Path('logs') / log_file
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_path)
        file_handler.setFormatter(file_formatter)
        handlers.append(file_handler)
    
    # Add handlers to logger
    for handler in handlers:
        logger.addHandler(handler)
    
    return logger

# Create default logger
logger = setup_logger(
    "app",
    log_file="app.log"
)

__all__ = ["logger", "setup_logger"] 