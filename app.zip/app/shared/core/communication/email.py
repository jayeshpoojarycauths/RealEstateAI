"""
Email communication utilities.
"""

import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any, Dict, Optional

import jinja2
from fastapi_mail import ConnectionConfig, FastMail, MessageSchema

from app.shared.core.communication.messages import MessageCode, Messages
from app.shared.core.config import settings
from app.shared.core.exceptions import CommunicationException
from app.shared.models.user import User

# Get logger directly
logger = logging.getLogger("app")

# Email configuration
conf = ConnectionConfig(
    MAIL_USERNAME=settings.MAIL_USERNAME,
    MAIL_PASSWORD=settings.MAIL_PASSWORD,
    MAIL_FROM=settings.MAIL_FROM,
    MAIL_PORT=settings.MAIL_PORT,
    MAIL_SERVER=settings.MAIL_SERVER,
    MAIL_FROM_NAME=settings.PROJECT_NAME,
    MAIL_STARTTLS=True,
    MAIL_SSL_TLS=False,
    USE_CREDENTIALS=True,
    TEMPLATE_FOLDER=Path(__file__).parent / 'email-templates'
)

# Initialize FastMail
fastmail = FastMail(conf)

# Initialize Jinja2
template_loader = jinja2.FileSystemLoader(searchpath=str(conf.TEMPLATE_FOLDER))
template_env = jinja2.Environment(loader=template_loader)

async def send_email(
    email_to: str,
    subject: str,
    template_name: str,
    template_data: Dict[str, Any]
) -> None:
    """Send an email using a template."""
    try:
        # Load and render template
        template = template_env.get_template(f"{template_name}.html")
        html_content = template.render(**template_data)
        
        # Create message
        message = MessageSchema(
            subject=subject,
            recipients=[email_to],
            body=html_content,
            subtype="html"
        )
        
        # Send email
        await fastmail.send_message(message)
        
    except Exception as e:
        # Log error but don't raise to prevent API disruption
        logger.error(f"Error sending email: {str(e)}")

async def send_verification_email(
    email_to: str,
    token: str,
    user_name: str
) -> None:
    """Send verification email."""
    subject = f"{settings.PROJECT_NAME} - Verify your email"
    template_data = {
        "project_name": settings.PROJECT_NAME,
        "user_name": user_name,
        "verification_url": f"{settings.SERVER_HOST}/verify-email?token={token}"
    }
    await send_email(email_to, subject, "verification", template_data)

async def send_password_reset_email(
    email_to: str,
    token: str,
    user_name: str
) -> None:
    """Send password reset email."""
    subject = f"{settings.PROJECT_NAME} - Password Reset"
    template_data = {
        "project_name": settings.PROJECT_NAME,
        "user_name": user_name,
        "reset_url": f"{settings.SERVER_HOST}/reset-password?token={token}"
    }
    await send_email(email_to, subject, "password_reset", template_data)

async def send_mfa_code_email(
    email_to: str,
    code: str,
    user_name: str
) -> None:
    """Send MFA code email."""
    subject = f"{settings.PROJECT_NAME} - Your MFA Code"
    template_data = {
        "project_name": settings.PROJECT_NAME,
        "user_name": user_name,
        "mfa_code": code
    }
    await send_email(email_to, subject, "mfa_code", template_data)

async def send_welcome_email(
    email_to: str,
    user_name: str
) -> None:
    """Send welcome email to new users."""
    subject = f"Welcome to {settings.PROJECT_NAME}!"
    template_data = {
        "project_name": settings.PROJECT_NAME,
        "user_name": user_name
    }
    await send_email(email_to, subject, "welcome", template_data)

class EmailService:
    """
    Service for sending emails.
    """
    
    def __init__(self):
        self.smtp_server = settings.MAIL_SERVER
        self.smtp_port = settings.MAIL_PORT
        self.smtp_username = settings.MAIL_USERNAME
        self.smtp_password = settings.MAIL_PASSWORD
        self.sender_email = settings.MAIL_FROM
        
    def send_email(
        self,
        recipient_email: str,
        subject: str,
        body: str,
        html_body: Optional[str] = None
    ) -> bool:
        """
        Send an email.
        """
        try:
            msg = MIMEMultipart()
            msg['From'] = self.sender_email
            msg['To'] = recipient_email
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'plain'))
            if html_body:
                msg.attach(MIMEText(html_body, 'html'))
                
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_username, self.smtp_password)
                server.send_message(msg)
                
            return True
        except Exception as e:
            raise CommunicationException(f"Failed to send email: {str(e)}")
            
    def send_welcome_email(self, user_id: str, db) -> bool:
        """
        Send welcome email to a new user.
        """
        # Use string-based query to avoid circular import
        user = db.query("User").filter_by(id=user_id).first()
        if not user:
            raise CommunicationException("User not found")
            
        subject = Messages.get(MessageCode.WELCOME_EMAIL_SUBJECT)
        body = Messages.get(MessageCode.WELCOME_EMAIL_BODY).format(
            user_name=user.full_name
        )
        
        return self.send_email(user.email, subject, body)
        
    def send_password_reset_email(self, user_id: str, reset_token: str, db) -> bool:
        """
        Send password reset email.
        """
        # Use string-based query to avoid circular import
        user = db.query("User").filter_by(id=user_id).first()
        if not user:
            raise CommunicationException("User not found")
            
        subject = Messages.get(MessageCode.PASSWORD_RESET_SUBJECT)
        body = Messages.get(MessageCode.PASSWORD_RESET_BODY).format(
            user_name=user.full_name,
            reset_link=f"{settings.FRONTEND_URL}/reset-password?token={reset_token}"
        )
        
        return self.send_email(user.email, subject, body)
        
    def send_notification_email(
        self,
        user_id: str,
        notification_type: str,
        data: Dict[str, Any],
        db
    ) -> bool:
        """
        Send notification email.
        """
        # Use string-based query to avoid circular import
        user = db.query("User").filter_by(id=user_id).first()
        if not user:
            raise CommunicationException("User not found")
            
        subject = Messages.get(f"{notification_type.upper()}_NOTIFICATION_SUBJECT")
        body = Messages.get(f"{notification_type.upper()}_NOTIFICATION_BODY").format(
            user_name=user.full_name,
            **data
        )
        
        return self.send_email(user.email, subject, body)

# Create a singleton instance
email_service = EmailService()

__all__ = [
    'send_email',
    'send_verification_email',
    'send_password_reset_email',
    'send_mfa_code_email',
    'send_welcome_email',
    'email_service',
] 