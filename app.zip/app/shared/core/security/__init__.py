"""
Security module initialization.
"""

from enum import Enum
from typing import Optional, Union

# Import roles first to avoid circular imports
from app.shared.core.security.roles import Role, UserRole

# Import auth functions
from app.shared.core.security.auth import (
    authenticate_user,
    get_current_user,
    get_current_active_user,
    get_current_superuser,
    get_current_customer,
    get_current_active_customer,
    get_current_tenant
)

# Import token functions
from app.shared.core.security.tokens import (
    create_access_token,
    create_refresh_token,
    decode_access_token,
    decode_refresh_token,
    verify_jwt_token,
    generate_verification_token,
    generate_password_reset_token
)

# Import security utilities
from app.shared.core.security.security import (
    encrypt_value,
    decrypt_value,
    hash_code,
    verify_mfa_code
)

# Import password utilities
from app.shared.core.security.password_utils import (
    get_password_hash,
    verify_password
)

# Import dependencies
from app.shared.core.security.dependencies import (
    require_role,
    require_permission,
    get_user_permissions,
    admin_required,
    manager_required,
    agent_required,
    viewer_required
)

# Import permissions
from app.shared.core.security.permissions import (
    PermissionService,
    require_admin,
    require_manager,
    require_agent,
    require_user_management,
    require_property_management,
    require_customer_management,
    require_system_management
)

# Re-export everything needed by other modules
__all__ = [
    # Roles
    "Role",
    "UserRole",
    
    # Auth functions
    "authenticate_user",
    "get_current_user",
    "get_current_active_user",
    "get_current_superuser",
    "get_current_customer",
    "get_current_active_customer",
    "get_current_tenant",
    
    # Token functions
    "create_access_token",
    "create_refresh_token",
    "decode_access_token",
    "decode_refresh_token",
    "verify_jwt_token",
    "generate_verification_token",
    "generate_password_reset_token",
    
    # Security utilities
    "encrypt_value",
    "decrypt_value",
    "hash_code",
    "verify_mfa_code",
    
    # Password utilities
    "get_password_hash",
    "verify_password",
    
    # Dependencies
    "require_role",
    "require_permission",
    "get_user_permissions",
    "admin_required",
    "manager_required",
    "agent_required",
    "viewer_required",
    
    # Permissions
    "PermissionService",
    "require_admin",
    "require_manager",
    "require_agent",
    "require_user_management",
    "require_property_management",
    "require_customer_management",
    "require_system_management"
] 