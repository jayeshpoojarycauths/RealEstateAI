"""
Authentication and authorization module.
"""

from datetime import datetime, timedelta
from typing import Optional, Union, Any
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from pydantic import ValidationError
from sqlalchemy.orm import Session
from passlib.context import CryptContext

from app.shared.core.config import settings
from app.shared.core.security.tokens import (
    create_access_token,
    create_refresh_token,
    decode_access_token,
    decode_refresh_token,
    verify_jwt_token
)
from app.shared.core.security.roles import Role
from app.shared.models.customer import Customer
from app.shared.core.security.password_utils import verify_password
from app.shared.core.infrastructure.database import get_db
from app.shared.core.exceptions import AuthenticationException
from app.shared.models.user import User
from sqlalchemy.orm import Session
from fastapi import Depends
from app.shared.models.user import User
from app.shared.db.session import get_db
from fastapi import HTTPException
from datetime import datetime
from typing import Any
from app.shared.core.exceptions import ValidationError
from datetime import timedelta

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def authenticate_user(
    db: Session,
    email: str,
    password: str
) -> Optional[User]:
    """
    Authenticate a user by email and password.
    
    Args:
        db: Database session
        email: User's email
        password: User's password
        
    Returns:
        User if authentication successful, None otherwise
    """
    user = db.query(User).filter(User.email == email).first()
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    """Get current user from token."""
    try:
        payload = decode_access_token(token)
        user_id: str = payload.get("sub")
        if user_id is None:
            raise AuthenticationException("Invalid token")
    except (JWTError, ValidationError):
        raise AuthenticationException("Invalid token")
        
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise AuthenticationException("User not found")
    return user

async def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """Get current active user."""
    if not current_user.is_active:
        raise AuthenticationException("Inactive user")
    return current_user

async def get_current_superuser(
    current_user: User = Depends(get_current_user)
) -> User:
    """Get current superuser."""
    if not current_user.is_superuser:
        raise AuthenticationException("Not enough permissions")
    return current_user

async def get_current_customer(
    current_user: User = Depends(get_current_user)
) -> Customer:
    """Get current customer."""
    if not current_user.customer_id:
        raise AuthenticationException("No customer associated")
    return current_user.customer

async def get_current_active_customer(
    current_customer: Customer = Depends(get_current_customer)
) -> Customer:
    """Get current active customer."""
    if not current_customer.is_active:
        raise AuthenticationException("Inactive customer")
    return current_customer

get_current_tenant = get_current_customer

# Re-export commonly used dependencies
__all__ = [
    "authenticate_user",
    "create_access_token",
    "create_refresh_token",
    "verify_password",
    "get_password_hash",
    "decode_access_token",
    "decode_refresh_token",
    "verify_jwt_token",
    "get_current_user",
    "get_current_active_user",
    "get_current_superuser",
    "get_current_customer",
    "get_current_active_customer",
    "get_current_tenant",
    "Role"
] 