"""
Authentication utilities.
"""

from typing import Any, Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.shared.core.config import settings
from app.shared.core.exceptions import AuthenticationException
from app.shared.core.infrastructure.database import get_db
from app.shared.core.security.password_utils import verify_password
from app.shared.core.security.roles import Role
from app.shared.models.customer import Customer
from sqlalchemy.orm import Session
from fastapi import Depends
from app.shared.models.user import User
from app.shared.db.session import get_db
from fastapi import HTTPException
from typing import Any
from sqlalchemy.orm import Session
from fastapi import Depends
from app.shared.models.user import User
from app.shared.db.session import get_db
from fastapi import HTTPException
from typing import Any

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> Any:
    """
    Get the current user from the token.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    
    # Use string reference to avoid circular import
    user = db.query("User").filter_by(id=user_id).first()
    if user is None:
        raise credentials_exception
    return user

async def get_current_active_user(
    current_user: Any = Depends(get_current_user)
) -> Any:
    """
    Get the current active user.
    """
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

async def get_current_superuser(
    current_user: Any = Depends(get_current_active_user)
) -> Any:
    """
    Get the current superuser.
    """
    if current_user.role != Role.SUPERUSER:
        raise HTTPException(
            status_code=403, detail="The user doesn't have enough privileges"
        )
    return current_user

async def authenticate_user(
    db: Session,
    email: str,
    password: str
) -> Optional[Any]:
    """
    Authenticate a user with email and password.
    """
    # Use string reference to avoid circular import
    user = db.query("User").filter_by(email=email).first()
    if not user:
        raise AuthenticationException("User not found")
    if not verify_password(password, user.hashed_password):
        raise AuthenticationException("Invalid password")
    return user

async def get_current_customer(
    current_user: Any = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> Customer:
    """
    Get the current customer.
    """
    customer = db.query(Customer).filter(
        Customer.id == current_user.customer_id
    ).first()
    if not customer:
        raise HTTPException(
            status_code=404,
            detail="Customer not found"
        )
    return customer 