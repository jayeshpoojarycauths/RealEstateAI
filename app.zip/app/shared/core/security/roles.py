"""
Role definitions for the application.
"""

from enum import Enum
from typing import TYPE_CHECKING
from app.shared.models.user import User
from app.shared.models.user import User

if TYPE_CHECKING:
    pass

class Role(str, Enum):
    """
    Role enumeration.
    """
    ADMIN = "admin"
    AGENT = "agent"
    CUSTOMER = "customer"
    USER = "user"

class UserRole(str, Enum):
    """
    User role enumeration.
    """
    ADMIN = "admin"
    AGENT = "agent"
    CUSTOMER = "customer"
    USER = "user"

__all__ = ["Role", "UserRole"] 