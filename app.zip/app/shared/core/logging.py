"""
Logging configuration and utilities.
Re-exports from infrastructure/logging.py for backward compatibility.
"""

from app.shared.core.infrastructure.logging import (
    get_logger,
    log_error,
    log_request,
    logger,
    setup_logging
)

__all__ = [
    'logger',
    'log_request',
    'log_error',
    'setup_logging',
    'get_logger'
] 