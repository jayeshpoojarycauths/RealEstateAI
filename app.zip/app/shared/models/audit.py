from sqlalchemy import JSON, Column, DateTime, ForeignKey, String
from sqlalchemy.orm import relationship

from app.shared.models.base import BaseModel
from app.shared.models.user import User
from app.shared.models.user import User


class AuditLog(BaseModel):
    """Audit log model for tracking system events."""
    __tablename__ = "audit_logs"

    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    customer_id = Column(String, ForeignKey("customers.id"), nullable=False)
    action = Column(String, nullable=False)
    resource_type = Column(String, nullable=False)
    resource_id = Column(String, nullable=False)
    details = Column(JSON)
    timestamp = Column(DateTime, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="audit_logs")
    customer = relationship("Customer", back_populates="audit_logs") 