"""
Shared models package initialization.
"""

from .audit import AuditLog
from .base import BaseModel
from .customer import Customer
from .interaction import InteractionLog
from .notification import Notification, NotificationPreference
from .user import User
from app.outreach.models.outreach import Outreach
from app.shared.models.interaction import InteractionLog
from app.shared.models.user import User

__all__ = [
    "AuditLog",
    "BaseModel",
    "Customer",
    "InteractionLog",
    "Notification",
    "NotificationPreference",
    "User",
    "Outreach"
]
