from datetime import datetime

from sqlalchemy import (JSON, Boolean, Column, DateTime, ForeignKey, Integer, String, Table)
from sqlalchemy.orm import relationship

from app.shared.core.security.roles import Role
from app.shared.models.base import BaseModel
from sqlalchemy.orm import Session
from app.shared.models.user import User
from datetime import datetime

# Association tables
user_roles = Table(
    'user_roles',
    BaseModel.metadata,
    Column('user_id', Integer, ForeignKey('users.id'), primary_key=True),
    Column('role_id', Integer, ForeignKey('roles.id'), primary_key=True)
)

role_permissions = Table(
    'role_permissions',
    BaseModel.metadata,
    Column('role_id', Integer, ForeignKey('roles.id'), primary_key=True),
    Column('permission_id', Integer, ForeignKey('permissions.id'), primary_key=True)
)

class User(BaseModel):
    """
    User model for authentication and authorization.
    """
    __tablename__ = "users"
    __table_args__ = {'extend_existing': True}

    id = Column(String, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    role = Column(String, default=Role.USER)
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean(), default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    customer_id = Column(String, ForeignKey("customers.id"), nullable=False)
    last_login = Column(DateTime)
    model_metadata = Column(JSON)  # Additional user metadata
    
    # Use string-based relationship references
    customer = relationship("Customer", back_populates="users")
    sessions = relationship("UserSession", back_populates="user", cascade="all, delete-orphan")
    refresh_tokens = relationship("RefreshToken", back_populates="user", cascade="all, delete-orphan")
    login_attempts = relationship("LoginAttempt", back_populates="user", cascade="all, delete-orphan")
    password_resets = relationship("PasswordReset", back_populates="user", cascade="all, delete-orphan")
    mfa_settings = relationship("MFASettings", back_populates="user", uselist=False, cascade="all, delete-orphan")
    
    # App-specific relationships
    leads = relationship("Lead", back_populates="user", cascade="all, delete-orphan")
    projects = relationship("Project", back_populates="user", cascade="all, delete-orphan")
    outreach_campaigns = relationship("OutreachCampaign", back_populates="user", cascade="all, delete-orphan")
    scraping_configs = relationship("ScrapingConfig", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User {self.email}>"

class Role(BaseModel):
    """Role model for role-based access control."""
    __tablename__ = "roles"

    name = Column(String, unique=True, index=True, nullable=False)
    description = Column(String)
    
    # Relationships
    users = relationship("User", secondary="user_roles", back_populates="roles")
    permissions = relationship("Permission", secondary="role_permissions", back_populates="roles")

class Permission(BaseModel):
    """Permission model for fine-grained access control."""
    __tablename__ = "permissions"

    name = Column(String, unique=True, index=True, nullable=False)
    description = Column(String)
    
    # Relationships
    roles = relationship("Role", secondary="role_permissions", back_populates="permissions") 