"""
Analytics schemas package.
""" 