"""
Analytics domain package.
""" 