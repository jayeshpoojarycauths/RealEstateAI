import React from 'react';

export const Customers: React.FC = () => <div>Customers Page</div>;
 
export default Customers; 