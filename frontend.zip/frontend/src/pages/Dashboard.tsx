import React from 'react';

export const Dashboard: React.FC = () => <div>Dashboard Page</div>;
 
export default Dashboard; 