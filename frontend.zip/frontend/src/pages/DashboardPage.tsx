import React from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Typography,
  Button,
} from "@material-tailwind/react";
import {
  UserGroupIcon,
  BuildingOfficeIcon,
  CurrencyDollarIcon,
  ChartBarIcon,
} from "@heroicons/react/24/outline";
import { useMaterialTailwind } from "../hooks/useMaterialTailwind";

export const DashboardPage: React.FC = () => {
  const { getButtonProps, getCardProps, getCardBodyProps, getCardHeaderProps, getTypographyProps } = useMaterialTailwind();

  const stats = [
    {
      title: "Total Leads",
      value: "2,300",
      change: "+3%",
      icon: UserGroupIcon,
      color: "blue",
    },
    {
      title: "Active Projects",
      value: "12",
      change: "+2%",
      icon: BuildingOfficeIcon,
      color: "green",
    },
    {
      title: "Revenue",
      value: "$34,245",
      change: "+5%",
      icon: CurrencyDollarIcon,
      color: "amber",
    },
    {
      title: "Conversion Rate",
      value: "2.4%",
      change: "+0.5%",
      icon: ChartBarIcon,
      color: "purple",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Typography variant="h4" color="blue-gray" {...getTypographyProps()}>
          Dashboard
        </Typography>
        <Button
          variant="filled"
          color="blue"
          className="flex items-center gap-2"
          {...getButtonProps()}
        >
          <ChartBarIcon className="h-5 w-5" />
          Generate Report
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} {...getCardProps()}>
              <CardBody {...getCardBodyProps()}>
                <div className="flex items-center justify-between">
                  <div>
                    <Typography
                      variant="small"
                      color="blue-gray"
                      className="font-normal"
                      {...getTypographyProps()}
                    >
                      {stat.title}
                    </Typography>
                    <Typography
                      variant="h4"
                      color="blue-gray"
                      {...getTypographyProps()}
                    >
                      {stat.value}
                    </Typography>
                  </div>
                  <div className="rounded-full bg-blue-50 p-3">
                    <Icon className={`h-6 w-6 text-${stat.color}-500`} />
                  </div>
                </div>
                <div className="mt-4">
                  <Typography
                    variant="small"
                    color="green"
                    className="flex items-center gap-1 font-normal"
                    {...getTypographyProps()}
                  >
                    {stat.change}
                  </Typography>
                </div>
              </CardBody>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card {...getCardProps()}>
          <CardHeader
            variant="gradient"
            color="blue"
            className="mb-4 p-6"
            {...getCardHeaderProps()}
          >
            <Typography variant="h6" color="white" {...getTypographyProps()}>
              Recent Leads
            </Typography>
          </CardHeader>
          <CardBody {...getCardBodyProps()}>
            <Typography variant="paragraph" color="blue-gray" {...getTypographyProps()}>
              Content coming soon...
            </Typography>
          </CardBody>
        </Card>

        <Card {...getCardProps()}>
          <CardHeader
            variant="gradient"
            color="blue"
            className="mb-4 p-6"
            {...getCardHeaderProps()}
          >
            <Typography variant="h6" color="white" {...getTypographyProps()}>
              Active Projects
            </Typography>
          </CardHeader>
          <CardBody {...getCardBodyProps()}>
            <Typography variant="paragraph" color="blue-gray" {...getTypographyProps()}>
              Content coming soon...
            </Typography>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}; 