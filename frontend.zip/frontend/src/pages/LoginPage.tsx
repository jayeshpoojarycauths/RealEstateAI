import React from "react";
import { useNavigate } from "react-router-dom";
import { useForm, SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardHeader,
  CardBody,
  Typography,
  Button,
  Input,
  Checkbox,
} from "@material-tailwind/react";
import { useMaterialTailwind } from "../hooks/useMaterialTailwind";
import { useAuth } from "../hooks/useAuth";
import { MFAVerification } from "../components/auth/MFAVerification";

// Define validation schema
const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  rememberMe: z.boolean().default(false),
});

type LoginFormData = z.infer<typeof loginSchema>;

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { login, requiresMFA } = useAuth();
  const { getButtonProps, getCardProps, getCardBodyProps, getCardHeaderProps, getTypographyProps, getInputProps } = useMaterialTailwind();
  const [error, setError] = React.useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
      rememberMe: false,
    },
  });

  const onSubmit: SubmitHandler<LoginFormData> = async (data) => {
    try {
      setError(null);
      await login(data.email, data.password, data.rememberMe);
      if (!requiresMFA) {
        navigate("/dashboard");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred during login");
    }
  };

  if (requiresMFA) {
    return <MFAVerification />;
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-md">
        <Card {...getCardProps()}>
          <CardHeader
            variant="gradient"
            color="blue"
            className="mb-4 grid h-28 place-items-center"
            {...getCardHeaderProps()}
          >
            <Typography variant="h3" color="white" {...getTypographyProps()}>
              Sign In
            </Typography>
            <Typography variant="small" color="white" {...getTypographyProps()}>
              Enter your email and password to sign in
            </Typography>
          </CardHeader>
          <CardBody {...getCardBodyProps()}>
            <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6">
              <div>
                <Input
                  type="email"
                  label="Email"
                  {...register('email')}
                  error={!!errors.email}
                  aria-invalid={!!errors.email}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  {...getInputProps()}
                />
                {errors.email && (
                  <Typography
                    variant="small"
                    color="red"
                    id="email-error"
                    {...getTypographyProps()}
                  >
                    {errors.email.message}
                  </Typography>
                )}
              </div>

              <div>
                <Input
                  type="password"
                  label="Password"
                  {...register('password')}
                  error={!!errors.password}
                  aria-invalid={!!errors.password}
                  aria-describedby={errors.password ? 'password-error' : undefined}
                  {...getInputProps()}
                />
                {errors.password && (
                  <Typography
                    variant="small"
                    color="red"
                    id="password-error"
                    {...getTypographyProps()}
                  >
                    {errors.password.message}
                  </Typography>
                )}
              </div>

              <div className="-ml-2.5">
                <Checkbox
                  label={
                    <Typography
                      variant="small"
                      color="gray"
                      className="flex items-center font-normal"
                      {...getTypographyProps()}
                    >
                      Remember me
                    </Typography>
                  }
                  containerProps={{ className: '-ml-2.5' }}
                  {...register('rememberMe')}
                />
              </div>

              {error && (
                <Typography
                  variant="small"
                  color="red"
                  role="alert"
                  {...getTypographyProps()}
                >
                  {error}
                </Typography>
              )}

              <Button
                type="submit"
                fullWidth
                disabled={isSubmitting}
                aria-busy={isSubmitting}
                {...getButtonProps()}
              >
                {isSubmitting ? 'Signing in...' : 'Sign In'}
              </Button>
            </form>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}; 