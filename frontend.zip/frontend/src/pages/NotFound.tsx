import React from 'react';

export const NotFound: React.FC = () => <div>404 - Not Found</div>;
 
export default NotFound; 