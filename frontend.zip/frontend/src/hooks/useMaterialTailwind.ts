import { useMemo } from 'react';
import { TypographyProps, ButtonProps } from '@material-tailwind/react';

export const useMaterialTailwind = () => {
  return useMemo(
    () => ({
      getButtonProps: (): Partial<ButtonProps> => ({
        className: 'bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded w-full justify-start',
      }),
      getCardProps: () => ({
        className: 'bg-white shadow-lg rounded-lg overflow-hidden',
      }),
      getCardHeaderProps: () => ({
        className: 'bg-gray-50 px-6 py-4 border-b border-gray-200',
      }),
      getCardBodyProps: () => ({
        className: 'p-6',
      }),
      getTypographyProps: (): Partial<TypographyProps> => ({
        className: 'text-gray-900',
      }),
      getInputProps: () => ({
        className: 'w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500',
      }),
    }),
    []
  );
}; 