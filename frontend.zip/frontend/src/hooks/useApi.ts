import { useCallback } from 'react';
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor for authentication
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized access
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const useApi = () => {
  const get = useCallback(
    async <T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
      return api.get<T>(url, config);
    },
    []
  );

  const post = useCallback(
    async <T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
      return api.post<T>(url, data, config);
    },
    []
  );

  const put = useCallback(
    async <T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
      return api.put<T>(url, data, config);
    },
    []
  );

  const del = useCallback(
    async <T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> => {
      return api.delete<T>(url, config);
    },
    []
  );

  return {
    get,
    post,
    put,
    delete: del,
  };
}; 