import React, { useState } from "react";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import {
  Card,
  CardBody,
  Typography,
  Button,
  Collapse,
} from "@material-tailwind/react";
import {
  Bars3Icon,
  XMarkIcon,
  HomeIcon,
  UserGroupIcon,
  FolderIcon,
  UserCircleIcon,
  ChartBarIcon,
} from "@heroicons/react/24/outline";
import { useMaterialTailwind } from "../hooks/useMaterialTailwind";

interface DashboardLayoutProps {
  children?: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();
  const { getButtonProps, getCardProps, getCardBodyProps, getTypographyProps } = useMaterialTailwind();

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navItems = [
    { path: "/leads", icon: <UserGroupIcon className="h-5 w-5" />, label: "Leads" },
    { path: "/projects", icon: <FolderIcon className="h-5 w-5" />, label: "Projects" },
    { path: "/stats", icon: <ChartBarIcon className="h-5 w-5" />, label: "Analytics" },
    { path: "/profile", icon: <UserCircleIcon className="h-5 w-5" />, label: "Profile" },
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between p-4 border-b">
            <Typography variant="h5" color="blue" {...getTypographyProps()}>
              Real Estate AI
            </Typography>
            <button
              onClick={toggleSidebar}
              className="md:hidden p-2 text-gray-500 hover:text-gray-700"
            >
              <XMarkIcon className="h-5 w-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Button
                    variant={isActive(item.path) ? "filled" : "text"}
                    color={isActive(item.path) ? "blue" : "blue-gray"}
                    onClick={() => navigate(item.path)}
                    {...getButtonProps()}
                  >
                    {item.icon}
                    <span className="ml-3">{item.label}</span>
                  </Button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Logout Button */}
          <div className="p-4 border-t">
            <Button
              variant="text"
              color="red"
              onClick={handleLogout}
              {...getButtonProps()}
            >
              <XMarkIcon className="h-5 w-5" />
              <span className="ml-3">Logout</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col md:ml-64">
        {/* Top Bar */}
        <header className="bg-white shadow-sm">
          <div className="flex items-center justify-between p-4">
            <button
              onClick={toggleSidebar}
              className="md:hidden p-2 text-gray-500 hover:text-gray-700"
            >
              <Bars3Icon className="h-5 w-5" />
            </button>
            <Typography variant="h6" color="blue-gray" {...getTypographyProps()}>
              {navItems.find((item) => isActive(item.path))?.label || "Dashboard"}
            </Typography>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6 overflow-auto">
          {children || <Outlet />}
        </main>
      </div>
    </div>
  );
}; 